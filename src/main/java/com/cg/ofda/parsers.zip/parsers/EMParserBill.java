package com.cg.ofda.parsers;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.ofda.entity.BillEntity;
import com.cg.ofda.model.BillModel;
import com.cg.ofda.repository.IBillRepository;

public class EMParserBill {
	
	@Autowired
	private IBillRepository billRepo;
	
	public static BillModel parse(BillEntity source) {
		return source==null ? null:
			new BillModel (
					EMParserOrderDetails.parse(source.getOrder()),
					source.getTotalItem(),
					source.getTotalCost(),
					source.getBillDate());
	}
	
	public static BillEntity parse(BillModel source) {
		return source==null ? null:
			new BillEntity (
					EMParserOrderDetails.parse(source.getOrder()),
					source.getTotalItem(),
					source.getTotalCost(),
					source.getBillDate());
	}

}

package com.cg.ofda.parsers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.ofda.entity.RestaurantEntity;
import com.cg.ofda.model.RestaurantModel;
import com.cg.ofda.repository.IRestaurantRepository;
import com.cg.ofda.service.*;

public class EMParserRestaurant {
	
	@Autowired
	private IRestaurantRepository billRepo;
	
	public static RestaurantModel parse(RestaurantEntity source) {
		return source==null ? null:
			new RestaurantModel (source.getRestaurantId(),
					source.getRestaurantName(),
					source.getAddress(),
					EMParserItem.parseEntity(source.getItemList()),
					source.getManagerName(),
					source.getContactNumber());
					
	}
	
	public static RestaurantEntity parse(RestaurantModel source) {
		return source==null ? null:
			new RestaurantEntity (source.getRestaurantId(),
					source.getRestaurantName(),
					source.getAddress(),
					EMParserItem.parse(source.getItemList()),
					source.getManagerName(),
					source.getContactNumber());
	}

	public static List<RestaurantEntity> parse(List<RestaurantModel> list){
		
		List<RestaurantEntity> rlist =new ArrayList<>();
		for(RestaurantModel model : list) {
			rlist.add(parse(model));
		}
		return rlist;
	}
	
	public static List<RestaurantModel> parseEntity(List<RestaurantEntity> list){
		
		List<RestaurantModel> rlist =new ArrayList<>();
		for(RestaurantEntity entity : list) {
			rlist.add(parse(entity));
		}
		return rlist;
	}
}

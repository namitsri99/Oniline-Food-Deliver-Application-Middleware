package com.cg.ofda.parsers;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.ofda.entity.OrderDetailsEntity;
import com.cg.ofda.model.OrderDetailsModel;
import com.cg.ofda.repository.IOrderRepository;
import com.cg.ofda.service.*;

public class EMParserOrderDetails {
	
	@Autowired
	private IOrderRepository orderRepo;
	
	public static OrderDetailsModel parse(OrderDetailsEntity source) {
		return source == null ? null:
			new OrderDetailsModel(source.getOrderDate(),
					EMParserFoodCart.parse(source.getCart()),
					source.getOrderStatus());
	}
	
	public static OrderDetailsEntity parse(OrderDetailsModel  source) {
		return source == null ? null:
			new OrderDetailsEntity(source.getOrderDate(),
					EMParserFoodCart.parse(source.getCart()),
					source.getOrderStatus());
	}
	

}

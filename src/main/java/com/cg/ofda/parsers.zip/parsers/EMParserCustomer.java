package com.cg.ofda.parsers;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.ofda.entity.BillEntity;
import com.cg.ofda.entity.CustomerEntity;
import com.cg.ofda.model.BillModel;
import com.cg.ofda.model.CustomerModel;
import com.cg.ofda.repository.IBillRepository;
import com.cg.ofda.repository.ICustomerRepository;

public class EMParserCustomer {

	@Autowired
	private ICustomerRepository customerRepo;
	
	public static CustomerModel parse(CustomerEntity source) {
		return source==null ? null:
			new CustomerModel(source.getCustomerId(),
					source.getFirstName(),
					source.getLastName(),
					source.getGender(),
					source.getAge(),
					source.getMobileNumber(),
					source.getAddress(),
					source.getEmail());
	}
	
	public static CustomerEntity parse(CustomerModel source) {
		return source==null ? null:
			new CustomerEntity(source.getCustomerId(),
					source.getFirstName(),
					source.getLastName(),
					source.getGender(),
					source.getAge(),
					source.getMobileNumber(),
					source.getAddress(),
					source.getEmail());
	}
	
	

}
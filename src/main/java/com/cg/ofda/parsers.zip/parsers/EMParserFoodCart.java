package com.cg.ofda.parsers;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.ofda.entity.FoodCartEntity;
import com.cg.ofda.model.FoodCartModel;
import com.cg.ofda.repository.ICartRepository;

public class EMParserFoodCart {
	
	@Autowired
	private ICartRepository cartRepo;
	
	public static FoodCartModel parse(FoodCartEntity source) {
		return source==null ? null:
			new FoodCartModel (source.getCartId(),
					EMParserCustomer.parse(source.getCustomer()));
	}
	
	public static FoodCartEntity parse(FoodCartModel source) {
		return source==null ? null:
			new FoodCartEntity (source.getCartId(),
					EMParserCustomer.parse(source.getCustomer()));
	}

}

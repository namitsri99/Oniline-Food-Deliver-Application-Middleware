package com.cg.ofda.parsers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.ofda.entity.ItemEntity;
import com.cg.ofda.entity.RestaurantEntity;
import com.cg.ofda.model.ItemModel;
import com.cg.ofda.model.RestaurantModel;
import com.cg.ofda.repository.IItemRepository;

public class EMParserItem {

	@Autowired
	private IItemRepository itemRepo;
	
	public static ItemEntity parse(ItemModel source) {
		return source == null ? null :
			new ItemEntity(source.getItemId(),
					source.getItemName(),
					source.getCategory(),
					source.getQuantity(),
					source.getCost(),
					EMParserRestaurant.parse(source.getRestaurants()),
					EMParserFoodCart.parse(source.getFoodCart()));
	}
	
	public static ItemModel parse(ItemEntity source) {
		return source == null ? null :
			new ItemModel(source.getItemId(),
					source.getItemName(),
					source.getCategory(),
					source.getQuantity(),
					source.getCost(),
					EMParserRestaurant.parseEntity(source.getRestaurants()),
					EMParserFoodCart.parse(source.getFoodCart()));
	}
	
	public static List<ItemEntity> parse(List<ItemModel> list){
		
		List<ItemEntity> rlist =new ArrayList<>();
		for(ItemModel model : list) {
			rlist.add(parse(model));
		}
		return rlist;
	}	

	public static List<ItemModel> parseEntity(List<ItemEntity> list){
		
		List<ItemModel> rlist =new ArrayList<>();
		for(ItemEntity entity : list) {
			rlist.add(parse(entity));
		}
		return rlist;
	}

}
